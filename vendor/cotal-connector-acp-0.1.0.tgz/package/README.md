# cotal-connector-acp

A [cotal](https://cotal.ai) connector that runs any [Agent Client Protocol](https://agentclientprotocol.com) agent as a first-class mesh agent. That covers `fx acp`, `codex-acp`, `gemini --acp`, `goose acp` and others. The manager spawns it like any other agent. It shows up in presence, it gets DMs and channel messages as turns, and it answers through the `cotal_*` tools. It has no paw dependency and no `@cotal-ai/*` runtime dependency.

## How it works

```
cotal manager ──spawns──▶ node dist/host.js   (one MeshAgent = the mesh identity)
                            │  loopback HTTP MCP (bearer token): cotal_dm, cotal_send, …
                            │
                            └─stdio JSON-RPC──▶ <acpCommand>   e.g. fx acp
```

1. The host starts a loopback Streamable-HTTP MCP endpoint that serves the `cotal_*` tools. It is bound to 127.0.0.1 and checks the Host header and a 32-byte bearer token.
2. It spawns the ACP agent and runs `initialize` (protocol v1, no fs or terminal capabilities). Then it runs `session/new` with a `cotal` MCP server entry:
   - If the agent advertises `mcpCapabilities.http`, the entry is an `http` entry with the bearer header.
   - Otherwise it is a **stdio shim** (`node dist/shim.js`) that proxies `tools/list` and `tools/call` to the same endpoint.

   In both cases there is only ever one mesh identity.
3. The host joins the mesh only after the session is open. If the agent or its MCP fails to start, the spawn fails instead of leaving a deaf agent online.
4. Each mesh message (a DM, a mention, or channel traffic when attention is `open`) becomes a `session/prompt`:
   - Messages that arrive while a turn is running are queued and coalesced into the next prompt. There is never a concurrent prompt.
   - A delivery is acked only after the turn ends cleanly. An error leaves it queued and retries with backoff (1s, doubling to 30s).
   - Presence is `working` from prompt to stopReason, and `idle` after it.
5. The first prompt carries the persona body, the mesh brief and the channel briefing, because generic ACP has no system prompt. Plain text the agent writes is **never** forwarded. Replies go out only through `cotal_dm`, `cotal_send` and `cotal_anycast`.
6. `session/request_permission` is answered automatically (see `permission` below). The connector never calls `session/set_mode` or `set_config_option`: fx persists those into the operator's global profile.
7. If the ACP agent exits on its own, the host logs the exit code and stderr tail, goes offline and exits 1. Revival belongs to the manager.

## Config

You can set three keys, in either of two places. A launch option takes precedence over the persona key.

| launch option | persona key | value |
|---|---|---|
| `command` | `acpCommand` | **required.** A JSON array, e.g. `["/Users/me/.local/bin/fx","acp","--model","grok-4.7"]`. A whitespace string is rejected, not split. |
| `env` | `acpEnv` | A JSON object merged into the agent's env, e.g. `{"FX_PERMISSION_MODE":"full-access"}` |
| `permission` | `acpPermission` | `allow` (default) or `reject`. `allow` picks the `allow_once` option, falling back to `allow_always`. `reject` picks `reject_once`, falling back to `reject_always`. If the wanted kind is missing, the answer is `cancelled` and the host logs it. |

In a persona, **quote the JSON**. An unquoted YAML list or map is not a scalar, and cotal's persona parser drops it:

```markdown
---
name: fxbot
agent: acp
acpCommand: '["/Users/me/.local/bin/fx","acp"]'
acpEnv: '{"FX_PERMISSION_MODE":"full-access"}'
---
You are fxbot. You fix flaky tests.
```

Other settings:

- **Extra instructions:** set `COTAL_ACP_INSTRUCTIONS` on the host env, for example from a wrapping connector, to append text to the first-turn preamble.
- **Logging in:** the agent must already be logged in. ACP `authMethods` flows are not driven, and `HOME` is forwarded, so `~/.fx` and similar directories are found.

The connector refuses the following loudly at spawn time:

- `resume` / `continueSession` / `reopenSession`
- `model` (put the model in the command instead)
- `variant`
- an initial `prompt`
- shared `mcpServers`

## Run

### Raw cotal

```bash
pnpm install && pnpm build
cotal ext add ./                      # → provides: connector:acp
cotal spawn fxbot                     # persona with agent: acp (above), or:
cotal spawn --agent acp --opt command='["/Users/me/.local/bin/fx","acp"]' --opt env='{"FX_PERMISSION_MODE":"full-access"}'
```

### paw

paw imports the package in `bin/cotald.ts` and wraps it (`src/acp.ts`). The wrapper adds the paw brief, beads, a short TMPDIR and `nice:`.

1. Write a persona with `agent: acp` and the keys above.
2. Run `paw dm <name> …`.

paw spawns it with `events: false` and `shareTools: none`.

### As a library

```ts
import { acpConnector } from "cotal-connector-acp"; // registers connector "acp" on import
registry.unregister("connector", "acp");
registry.register({ ...acpConnector, buildLaunch: (o) => wrap(acpConnector.buildLaunch(o)) });
```

## Test

```bash
pnpm test        # builds, then the hermetic node:test suite (fake ACP agent, no mesh, no network)
pnpm typecheck
```

`test/fake-acp-agent.mjs` is a scripted ndjson ACP agent configured through env vars:

- delays
- permission requests
- errors
- crash on prompt
- stdio-only MCP
- -32600 on a concurrent prompt, as fx does

The suite covers:

- the handshake and the `mcpServers` entry it passes
- the choice between an http and a stdio entry
- the permission policy
- inbound message → prompt
- coalescing while a turn runs
- drain only after `end_turn`
- retry on error
- presence ordering
- an agent crash surfacing loudly with nothing acked
- the built shim proxying against an authenticated endpoint

## Not yet

These are out of scope for v1:

- session resume (every spawn is a fresh `session/new`)
- steering (fx `_meta.fx.steer`)
- an initial prompt
- model or variant selection through cotal
- forwarding shared operator MCP servers
- an AG-UI event plane
- a TUI or attach
- images and files in prompts
- ACP auth flows

These agents have not been tested live: `codex-acp`, `gemini --acp` and `goose acp`. Only `fx acp` (0.0.14, grok-4.7) has been exercised end to end.

## License

MIT © caffeinum
